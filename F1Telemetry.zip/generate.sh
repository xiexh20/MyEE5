java -classpath jooq-3.13.1.jar:jooq-meta-3.13.1.jar:jooq-codegen-3.13.1.jar:reactive-streams-1.0.2.jar:mysql-connector-java-5.1.48-bin.jar:. org.jooq.codegen.GenerationTool F1GameDB.xml
